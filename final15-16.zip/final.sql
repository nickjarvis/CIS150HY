--Q1
--Write a SQL query that retrieves all languages
 --that occur in more than 1000 Webpages.
 --A language "occurs" in a Webpage if the Webpage
 --contains a word in that language"

select y.language
from Occurs x, Dictionary y
where x.word = y.word
group by y.language
having count(*) > 1000s

--Q2
--Write a SQL query that computes, for each Webpage,
--the largest number of words on that page in any
--language. For example, if a page has 100 words in
--French and 50 words in English (these two sets of
--words may be overlapping), then your query will
--return 100 for that page. If a Webpage has only
--words that do not occur in any language at all, then you do not need to return that Webpage.

select url, max(F)
from (select x.url, y.language, count(*) as F
from Occur x, Dictionary y
where x.word = y.word
group by x.url, y.language)
group by url

--Q3
--We say that a Webpage is "monolingual in X" if all
--words occurring on that Webpage are in the language X
--(and may be in other languages too). Write a query
--in the Relational Calculus that returns all monolingual
--Webpages together with the language(s) in which they
--are monolingual. For example, if the Webpage is:
--Introduction to Data Management then your query
--should return English for that Webpage, because
--all four words are in English, hence the Webpage
--s monolingual in English. (The word Data occurs in
--other languages as well, but not he other three
--words.) On the other hand, if the Webpage is:
-- NO SQL ! then it is monolingual in English, in
--French, in Italian, etc, because both NO and SQL
-- are words in English, in French, in Italian.
--because NO is not a Dutch word; Dutch people
--say 'NEE').

Add O(x, −) and D(−, r):

--Q7
--Add a common table expression to our Movie database.

CREATE TABLE `movie status` (
    `movie_id` int  NOT NULL ,
    `status` int  NOT NULL ,
